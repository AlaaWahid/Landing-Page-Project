Landing Page Project

Project Description:

-We create a page that contains a header and four sections.
-That four sections have four links as when clicking any link, will scroll smoothly to the section related to the link.
-When we at any section, will appear at window as viewport. 
-When we at active section, it refers to this active link.


Programming Languages:
HTML5, ES6


Folder Structure
css
- styles.css    
index.html
js
- app.js
README.md


Modify HTML Sheet:

-Added section no.4


Modify CSS Sheet:

-Changed background of active class
-changed active link color, background, text-align to center and separate between them by " | "
